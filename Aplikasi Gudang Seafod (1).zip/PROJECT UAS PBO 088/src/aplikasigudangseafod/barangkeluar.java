/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package aplikasigudangseafod;

import java.awt.print.PrinterException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class barangkeluar extends javax.swing.JFrame {
    
    private DefaultTableModel model = null;
    private PreparedStatement stat;
    private ResultSet rs;
    koneksi bk = new koneksi();
    private int id_pengguna = 0;
    String peran = "";

    public barangkeluar() {
        initComponents();
        bk.connect();
        table();
    }
    
    public void refreshKoneksi() {
        try {
            bk.disconnect();  // Menutup koneksi yang ada
            bk.connect();     // Membuka koneksi baru
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }

    public void setId_pengguna(int id_pengguna) {
        this.id_pengguna = id_pengguna;
    }

    public void setPeran(String peran) {
        this.peran = peran;
    }
    
    class barang {
        int id_barang_keluar, id_barang, stok_barang, id_pelanggan, jumlah_keluar, harga_jual, total_harga;
        String nama_barang, nama_pelanggan, tanggal;
        public barang() {
            String combo_b = cb_barang.getSelectedItem().toString();
            String[] arr_b = combo_b.split(":");
            this.id_barang = Integer.parseInt(arr_b[0]);
            this.nama_barang = arr_b[1];
            this.stok_barang = Integer.parseInt(arr_b[2]);
            this.harga_jual = Integer.parseInt(arr_b[3]);
            String combo_p = cb_pelanggan.getSelectedItem().toString();
            String[] arr_p = combo_p.split(":");
            this.id_pelanggan = Integer.parseInt(arr_p[0]);
            this.nama_pelanggan = arr_p[1];
            try {
                Date date = txtdate.getDate();
                DateFormat dateformat = new SimpleDateFormat("YYYY-MM-dd");
                this.tanggal = dateformat.format(date);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
            this.jumlah_keluar = Integer.parseInt(txt_jumlah_keluar.getText());
            this.total_harga = this.harga_jual * this.jumlah_keluar;
        }
    }
    
    public void refreshCombo() {
    refreshKoneksi();
        try {
            cb_barang.removeAllItems(); // Menghapus semua item lama dari cb_barang

            // Mengambil data barang dari database
            this.stat = bk.getCon().prepareStatement("SELECT * FROM barang");
            this.rs = this.stat.executeQuery();
            while (rs.next()) {
                cb_barang.addItem(rs.getString("id_barang") + ":" + rs.getString("nama_barang") + ":" + rs.getInt("stok_barang") + ":" + rs.getInt("harga_jual"));
        }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        try {
            this.stat = bk.getCon().prepareStatement("select * from pelanggan");
            this.rs = this.stat.executeQuery();
            while(rs.next()) {
                cb_pelanggan.addItem(rs.getString("id_pelanggan")+":"+rs.getString("nama_pelanggan"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void kurangistokbarang() {
        barang br = new barang();
        try {
            this.stat = bk.getCon().prepareStatement("UPDATE barang SET stok_barang = stok_barang - ? WHERE id_barang = ?");

            stat.setInt(1, br.jumlah_keluar);
            stat.setInt(2, br.id_barang);

            stat.executeUpdate();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void table() {
        try {
            refreshKoneksi();
            refreshCombo();
            this.stat = bk.getCon().prepareStatement("select * from barang_keluar");
            this.rs = stat.executeQuery();
            
            model = new DefaultTableModel();
            model.addColumn("No");
            model.addColumn("Barang");
            model.addColumn("Pelanggan");
            model.addColumn("Tanggal");
            model.addColumn("Jumlah Keluar");
            model.addColumn("Total Harga");
            
            model.getDataVector().removeAllElements();
            model.fireTableDataChanged();
            
            while (rs.next()){
                Object[] data ={
                    rs.getString("id_barang_keluar"),
                    rs.getString("nama_barang"),
                    rs.getString("nama_pelanggan"),
                    rs.getString("tanggal_transaksi"),
                    rs.getString("jumlah_keluar"),
                    rs.getString("total_harga")
                };
                model.addRow(data);
                tblkeluar.setModel(model);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        txtdate.setCalendar(null);
        txt_jumlah_keluar.setText("");
        txt_total_harga.setText("");
    }
    
    // Method untuk menambahkan data pengguna ke dalam database
    public void input() {
        barang br = new barang();
        if(br.stok_barang >= br.jumlah_keluar) {
            try {
                this.stat = bk.getCon().prepareStatement("insert into barang_keluar values (?,?,?,?,?,?,?,?,?)");
                txt_total_harga.setText(""+br.total_harga);
                stat.setInt(1, 0);
                stat.setInt(2, br.id_barang);
                stat.setString(3, br.nama_barang);
                stat.setInt(4, br.harga_jual);
                stat.setInt(5, br.id_pelanggan);
                stat.setString(6, br.nama_pelanggan);
                stat.setString(7, br.tanggal);
                stat.setInt(8, br.jumlah_keluar);
                stat.setInt(9, br.total_harga);

                stat.executeUpdate();
                JOptionPane.showMessageDialog(null, "Data berhasil ditambahkan!");
                kurangistokbarang();
                table();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
        }else if(br.stok_barang <= br.jumlah_keluar) {
            JOptionPane.showMessageDialog(null, "Jumlah keluar melebihi stok barang "+ br.nama_barang);
        }
    }
    
    // Method untuk mengedit data pengguna pada database
    public void editData() {
        try {
            barang br = new barang();
            int row = tblkeluar.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(null, "Silakan pilih data yang akan diubah!");
                return;
            }
            this.stat = bk.getCon().prepareStatement ("UPDATE barang_keluar SET id_barang=?, nama_barang=?, harga_jual=?, id_pelanggan=?, nama_pelanggan=?, tanggal_transaksi=?, jumlah_keluar=?, total_harga=? WHERE id_barang_keluar=?");

            stat.setInt(1, br.id_barang);
            stat.setString(2, br.nama_barang);
            stat.setInt(3, br.harga_jual);
            stat.setInt(4, br.id_pelanggan);
            stat.setString(5, br.nama_pelanggan);
            stat.setString(6, br.tanggal);
            stat.setInt(7, br.jumlah_keluar);
            stat.setInt(8, br.total_harga);
            stat.setString(9, tblkeluar.getValueAt(row, 0).toString());

            stat.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data berhasil diubah!");
            table();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    // Method untuk menghapus data pengguna dari database
    public void hapusData() {
        int row = tblkeluar.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(null, "Silakan pilih data yang akan dihapus!");
                return;
            }else {
                int jawab = JOptionPane.showConfirmDialog(null, "Data ini akan dihapus, lanjutkan?", "konfirmasi", JOptionPane.YES_NO_OPTION);
                if (jawab == 0) {
                    try {
                        this.stat = bk.getCon().prepareStatement("delete from barang_keluar where id_barang_keluar=?");

                        stat.setString(1, tblkeluar.getValueAt(row, 0).toString());

                        stat.executeUpdate();
                        JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
                        table();
                    } catch (Exception e) {
                    }
                }
            }
    }
    
    // Method untuk mencari data pengguna berdasarkan nama pengguna atau username
    public void cariData() {
        try {
            String keyword = txtcari.getText();
            this.stat = bk.getCon().prepareStatement("SELECT * FROM barang_keluar WHERE nama_barang LIKE '%" + keyword + "%' OR nama_pelanggan LIKE '%" + keyword + "%' OR tanggal_transaksi LIKE '%" + keyword + "%' OR jumlah_keluar LIKE '%" + keyword + "%'");
            rs = stat.executeQuery();

            model = new DefaultTableModel();
            model.addColumn("No");
            model.addColumn("Barang");
            model.addColumn("Pelanggan");
            model.addColumn("Tanggal");
            model.addColumn("Jumlah Keluar");
            model.addColumn("Total Harga");
            
            model.getDataVector().removeAllElements();
            model.fireTableDataChanged();
            
            while (rs.next()){
                Object[] data ={
                    rs.getString("id_barang_keluar"),
                    rs.getString("nama_barang"),
                    rs.getString("nama_pelanggan"),
                    rs.getString("tanggal_transaksi"),
                    rs.getString("jumlah_keluar"),
                    rs.getString("total_harga")
                };
                model.addRow(data);
                tblkeluar.setModel(model);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    // Method untuk menampilkan data pengguna pada field input
    public void tampilData() {
        txt_jumlah_keluar.setText(tblkeluar.getValueAt(tblkeluar.getSelectedRow(), 4).toString());
        txt_total_harga.setText(tblkeluar.getValueAt(tblkeluar.getSelectedRow(), 5).toString());
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        demoBundle1 = new datechooser.demo.locale.DemoBundle();
        jInternalFrame1 = new javax.swing.JInternalFrame();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        cb_pelanggan = new javax.swing.JComboBox<>();
        txt_jumlah_keluar = new javax.swing.JTextField();
        txt_total_harga = new javax.swing.JTextField();
        btninput = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        btndelete = new javax.swing.JButton();
        btn_search = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblkeluar = new javax.swing.JTable();
        txtcari = new javax.swing.JTextField();
        txtdate = new com.toedter.calendar.JDateChooser();
        cb_barang = new javax.swing.JComboBox<>();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        btnprint = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        btnhome = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        micontact = new javax.swing.JMenuItem();

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jInternalFrame1.setVisible(true);

        javax.swing.GroupLayout jInternalFrame1Layout = new javax.swing.GroupLayout(jInternalFrame1.getContentPane());
        jInternalFrame1.getContentPane().setLayout(jInternalFrame1Layout);
        jInternalFrame1Layout.setHorizontalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jInternalFrame1Layout.setVerticalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        jLabel1.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("BARANG KELUAR");

        jLabel2.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel2.setText("Barang");

        jLabel3.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel3.setText("Pelanggan");

        jLabel4.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel4.setText("Tanggal");

        jLabel5.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel5.setText("jumlah Keluar");

        jLabel6.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel6.setText("Total Harga");

        cb_pelanggan.setFont(new java.awt.Font("Consolas", 0, 14)); // NOI18N
        cb_pelanggan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cb_pelangganActionPerformed(evt);
            }
        });

        txt_jumlah_keluar.setFont(new java.awt.Font("Consolas", 0, 14)); // NOI18N

        txt_total_harga.setFont(new java.awt.Font("Consolas", 0, 14)); // NOI18N
        txt_total_harga.setEnabled(false);

        btninput.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btninput.setText("Input");
        btninput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btninputActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jButton2.setText("Update");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        btndelete.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btndelete.setText("Delete");
        btndelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndeleteActionPerformed(evt);
            }
        });

        btn_search.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btn_search.setText("Search");
        btn_search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_searchActionPerformed(evt);
            }
        });

        tblkeluar.setFont(new java.awt.Font("Consolas", 0, 14)); // NOI18N
        tblkeluar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "No", "Barang", "Pelanggan", "Tanggal", "Jumlah Keluar", "Total Harga"
            }
        ));
        tblkeluar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblkeluarMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tblkeluar);

        txtcari.setFont(new java.awt.Font("Consolas", 0, 14)); // NOI18N
        txtcari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcariActionPerformed(evt);
            }
        });

        cb_barang.setFont(new java.awt.Font("Consolas", 0, 14)); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btn_search)
                        .addGap(18, 18, 18)
                        .addComponent(txtcari, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGap(33, 33, 33)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtdate, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(cb_barang, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(cb_pelanggan, 0, 250, Short.MAX_VALUE)))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(60, 60, 60)
                                .addComponent(btninput)
                                .addGap(63, 63, 63)
                                .addComponent(btndelete)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 68, Short.MAX_VALUE)
                                .addComponent(jButton2))))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 662, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(153, 153, 153)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel5)
                                .addComponent(jLabel6)
                                .addComponent(jLabel4)
                                .addComponent(jLabel3)
                                .addComponent(jLabel2))
                            .addGap(18, 18, 18)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txt_jumlah_keluar, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                                .addComponent(txt_total_harga)))))
                .addContainerGap(15, Short.MAX_VALUE))
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cb_barang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cb_pelanggan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jLabel4))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtdate, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txt_jumlah_keluar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txt_total_harga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btninput)
                    .addComponent(btndelete)
                    .addComponent(jButton2)
                    .addComponent(btn_search)
                    .addComponent(txtcari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(66, Short.MAX_VALUE))
        );

        jMenu1.setText("File");

        btnprint.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ikon/export.png"))); // NOI18N
        btnprint.setText("Print");
        btnprint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnprintActionPerformed(evt);
            }
        });
        jMenu1.add(btnprint);
        jMenu1.add(jSeparator2);

        btnhome.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ikon/home.png"))); // NOI18N
        btnhome.setText("Home");
        btnhome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhomeActionPerformed(evt);
            }
        });
        jMenu1.add(btnhome);

        jMenuBar1.add(jMenu1);

        jMenu3.setText("Help");

        micontact.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ikon/contact.png"))); // NOI18N
        micontact.setText("Contact ");
        micontact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                micontactActionPerformed(evt);
            }
        });
        jMenu3.add(micontact);

        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btninputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btninputActionPerformed
        input();
    }//GEN-LAST:event_btninputActionPerformed

    private void txtcariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcariActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcariActionPerformed

    private void btnhomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhomeActionPerformed
        home home1 = new home();
        home1.setId_pengguna(id_pengguna);
        home1.setPeran(peran);
        home1.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnhomeActionPerformed

    private void micontactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_micontactActionPerformed
        JOptionPane.showMessageDialog(null, "Dimas-085236795262");
    }//GEN-LAST:event_micontactActionPerformed

    private void btndeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndeleteActionPerformed
        hapusData();
    }//GEN-LAST:event_btndeleteActionPerformed

    private void cb_pelangganActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cb_pelangganActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cb_pelangganActionPerformed

    private void tblkeluarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblkeluarMouseClicked
        tampilData();
    }//GEN-LAST:event_tblkeluarMouseClicked

    private void btn_searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_searchActionPerformed
        cariData();
    }//GEN-LAST:event_btn_searchActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        editData();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btnprintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnprintActionPerformed
        MessageFormat header = new MessageFormat("Barang Keluar");
        MessageFormat footer = new MessageFormat("Gudang Seafod");
        
        try {
            tblkeluar.print(JTable.PrintMode.FIT_WIDTH, header, footer);
        } catch (PrinterException e) {
            JOptionPane.showMessageDialog(null,"Cannot be print" + e.getMessage());
        }
    }//GEN-LAST:event_btnprintActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(databarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(databarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(databarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(databarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new barangkeluar().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_search;
    private javax.swing.JButton btndelete;
    private javax.swing.JMenuItem btnhome;
    private javax.swing.JButton btninput;
    private javax.swing.JMenuItem btnprint;
    private javax.swing.JComboBox<String> cb_barang;
    private javax.swing.JComboBox<String> cb_pelanggan;
    private datechooser.demo.locale.DemoBundle demoBundle1;
    private javax.swing.JButton jButton2;
    private javax.swing.JInternalFrame jInternalFrame1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JMenuItem micontact;
    private javax.swing.JTable tblkeluar;
    private javax.swing.JTextField txt_jumlah_keluar;
    private javax.swing.JTextField txt_total_harga;
    private javax.swing.JTextField txtcari;
    private com.toedter.calendar.JDateChooser txtdate;
    // End of variables declaration//GEN-END:variables
}
