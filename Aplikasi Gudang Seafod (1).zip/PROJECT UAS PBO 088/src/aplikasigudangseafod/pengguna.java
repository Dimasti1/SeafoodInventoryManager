/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package aplikasigudangseafod;

import java.awt.print.PrinterException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;
import java.text.MessageFormat;
import javax.swing.JOptionPane;
import javax.swing.JTable;



/**
 *
 * @author DIMAS
 */
public class pengguna extends javax.swing.JFrame {

    private DefaultTableModel model = null;
    private PreparedStatement stat;
    private ResultSet rs;
    koneksi k = new koneksi();
    private int id_pengguna = 0;
    String peran = "";
    
    public pengguna() {
        initComponents();
        k.connect();
        table();
    }

    public void setId_pengguna(int id_pengguna) {
        this.id_pengguna = id_pengguna;
    }

    public void setPeran(String peran) {
        this.peran = peran;
    }
    
    public void table() {
        try {
            this.stat = k.getCon().prepareStatement("select * from pengguna");
            this.rs = stat.executeQuery();
            
            model = new DefaultTableModel();
            model.addColumn("No");
            model.addColumn("Nama");
            model.addColumn("Username");
            model.addColumn("Password");
            model.addColumn("Peran");
            
            model.getDataVector().removeAllElements();
            model.fireTableDataChanged();
            
            while (rs.next()){
                Object[] data ={
                    rs.getString("id_pengguna"),
                    rs.getString("nama_pengguna"),
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("peran")
                };
                model.addRow(data);
                tblpengguna.setModel(model);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        txtnama_pengguna.setText("");
        txtusername.setText("");
        txtpassword.setText("");
    }
    
    
    // Method untuk menambahkan data pengguna ke dalam database
    public void input() {
        try {
            this.stat = k.getCon().prepareStatement("insert into pengguna values(?,?,?,?,?)");

            stat.setInt(1, 0);
            stat.setString(2, txtnama_pengguna.getText());
            stat.setString(3, txtusername.getText());
            stat.setString(4, txtpassword.getText());
            stat.setString(5, cbperan.getSelectedItem().toString());

            stat.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data berhasil ditambahkan!");
            table();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    // Method untuk mengedit data pengguna pada database
    public void editData() {
        try {
            int row = tblpengguna.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(null, "Silakan pilih data yang akan diubah!");
                return;
            }
            this.stat = k.getCon().prepareStatement ("UPDATE pengguna SET nama_pengguna=?, username=?, password=?, peran=? WHERE id_pengguna=?");

            stat.setString(1, txtnama_pengguna.getText());
            stat.setString(2, txtusername.getText());
            stat.setString(3, txtpassword.getText());
            stat.setString(4, cbperan.getSelectedItem().toString());
            stat.setString(5, tblpengguna.getValueAt(row, 0).toString());

            stat.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data berhasil diubah!");
            table();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    // Method untuk menghapus data pengguna dari database
    public void hapusData() {
        int row = tblpengguna.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(null, "Silakan pilih data yang akan dihapus!");
                return;
            }else {
                int jawab = JOptionPane.showConfirmDialog(null, "Data ini akan dihapus, lanjutkan?", "konfirmasi", JOptionPane.YES_NO_OPTION);
                if (jawab == 0) {
                    try {
                        this.stat = k.getCon().prepareStatement("delete from pengguna where id_pengguna=?");

                        stat.setString(1, tblpengguna.getValueAt(row, 0).toString());

                        stat.executeUpdate();
                        JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
                        table();
                    } catch (Exception e) {
                    }
                }
            }
            
    }

    // Method untuk mencari data pengguna berdasarkan nama pengguna atau username
    public void cariData() {
        try {
            String keyword = txtcari.getText();
            this.stat = k.getCon().prepareStatement("SELECT * FROM pengguna WHERE nama_pengguna LIKE '%" + keyword + "%' OR username LIKE '%" + keyword + "%' OR peran LIKE '%" + keyword + "%'");
            rs = stat.executeQuery();

            model = new DefaultTableModel();
            model.addColumn("No");
            model.addColumn("Nama Pengguna");
            model.addColumn("Username");
            model.addColumn("Password");
            model.addColumn("Peran");

            model.getDataVector().removeAllElements();
            model.fireTableDataChanged();

            while (rs.next()) {
                Object[] data = {
                    rs.getString("id_pengguna"),
                    rs.getString("nama_pengguna"),
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("peran")
                };
                model.addRow(data);
                tblpengguna.setModel(model);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }

    // Method untuk menampilkan data pengguna pada field input
    public void tampilData() {
        txtnama_pengguna.setText(tblpengguna.getValueAt(tblpengguna.getSelectedRow(), 1).toString());
        txtusername.setText(tblpengguna.getValueAt(tblpengguna.getSelectedRow(), 2).toString());
        txtpassword.setText(tblpengguna.getValueAt(tblpengguna.getSelectedRow(), 3).toString());
    }
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtnama_pengguna = new javax.swing.JTextField();
        txtusername = new javax.swing.JTextField();
        btninput = new javax.swing.JButton();
        btnupdate = new javax.swing.JButton();
        btndelete = new javax.swing.JButton();
        btnsearch = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblpengguna = new javax.swing.JTable();
        txtcari = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtpassword = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        cbperan = new javax.swing.JComboBox<>();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        btnprint = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        mihome = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        micontact = new javax.swing.JMenuItem();

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        jLabel1.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("PENGGUNA");

        jLabel2.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel2.setText("Nama");

        jLabel5.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel5.setText("Username");

        txtnama_pengguna.setFont(new java.awt.Font("Consolas", 0, 14)); // NOI18N
        txtnama_pengguna.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnama_penggunaActionPerformed(evt);
            }
        });

        txtusername.setFont(new java.awt.Font("Consolas", 0, 14)); // NOI18N

        btninput.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btninput.setText("Input");
        btninput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btninputActionPerformed(evt);
            }
        });

        btnupdate.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnupdate.setText("Update");
        btnupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdateActionPerformed(evt);
            }
        });

        btndelete.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btndelete.setText("Delete");
        btndelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndeleteActionPerformed(evt);
            }
        });

        btnsearch.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnsearch.setText("Search");
        btnsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsearchActionPerformed(evt);
            }
        });

        tblpengguna.setFont(new java.awt.Font("Consolas", 0, 14)); // NOI18N
        tblpengguna.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Nama", "Username", "Password", "Peran"
            }
        ));
        tblpengguna.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblpenggunaMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tblpengguna);
        if (tblpengguna.getColumnModel().getColumnCount() > 0) {
            tblpengguna.getColumnModel().getColumn(0).setHeaderValue("No");
        }

        txtcari.setFont(new java.awt.Font("Consolas", 0, 14)); // NOI18N
        txtcari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcariActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel6.setText("Password");

        txtpassword.setFont(new java.awt.Font("Consolas", 0, 14)); // NOI18N
        txtpassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtpasswordActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel3.setText("Peran");

        cbperan.setFont(new java.awt.Font("Consolas", 0, 14)); // NOI18N
        cbperan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Admin", "Pegawai" }));
        cbperan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbperanActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(141, 141, 141)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel3)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnsearch)
                                .addGap(18, 18, 18)
                                .addComponent(txtcari, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txtpassword, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtusername, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtnama_pengguna, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cbperan, 0, 250, Short.MAX_VALUE))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(btninput)
                                .addGap(60, 60, 60)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnupdate, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(btndelete)
                                        .addGap(135, 135, 135))))))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 662, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(18, Short.MAX_VALUE))
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtnama_pengguna, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtusername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtpassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cbperan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btndelete)
                    .addComponent(btnupdate)
                    .addComponent(btninput)
                    .addComponent(btnsearch)
                    .addComponent(txtcari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(32, Short.MAX_VALUE))
        );

        jMenu1.setText("File");

        btnprint.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ikon/export.png"))); // NOI18N
        btnprint.setText("Print");
        btnprint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnprintActionPerformed(evt);
            }
        });
        jMenu1.add(btnprint);
        jMenu1.add(jSeparator2);

        mihome.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ikon/home.png"))); // NOI18N
        mihome.setText("Home");
        mihome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mihomeActionPerformed(evt);
            }
        });
        jMenu1.add(mihome);

        jMenuBar1.add(jMenu1);

        jMenu3.setText("Help");

        micontact.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ikon/contact.png"))); // NOI18N
        micontact.setText("Contact ");
        micontact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                micontactActionPerformed(evt);
            }
        });
        jMenu3.add(micontact);

        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void micontactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_micontactActionPerformed
        JOptionPane.showMessageDialog(null, "Dimas-085236795262");
    }//GEN-LAST:event_micontactActionPerformed

    private void mihomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mihomeActionPerformed
        home h = new home();
        h.setId_pengguna(id_pengguna);
        h.setPeran(peran);
        h.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_mihomeActionPerformed

    private void btnprintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnprintActionPerformed
        MessageFormat header = new MessageFormat("Data Pengguna");
        MessageFormat footer = new MessageFormat("Gudang Seafod");
        
        try {
            tblpengguna.print(JTable.PrintMode.FIT_WIDTH, header, footer);
        } catch (PrinterException e) {
            JOptionPane.showMessageDialog(null,"Cannot be print" + e.getMessage());
        }
    }//GEN-LAST:event_btnprintActionPerformed

    private void cbperanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbperanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbperanActionPerformed

    private void txtpasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtpasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtpasswordActionPerformed

    private void txtcariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcariActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcariActionPerformed

    private void tblpenggunaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblpenggunaMouseClicked
        tampilData();
    }//GEN-LAST:event_tblpenggunaMouseClicked

    private void btnsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsearchActionPerformed
        cariData();
    }//GEN-LAST:event_btnsearchActionPerformed

    private void btndeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndeleteActionPerformed
        hapusData();
    }//GEN-LAST:event_btndeleteActionPerformed

    private void btnupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdateActionPerformed
        editData();
    }//GEN-LAST:event_btnupdateActionPerformed

    private void btninputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btninputActionPerformed
        input();
    }//GEN-LAST:event_btninputActionPerformed

    private void txtnama_penggunaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnama_penggunaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnama_penggunaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(databarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(databarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(databarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(databarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new pengguna().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btndelete;
    private javax.swing.JButton btninput;
    public javax.swing.JMenuItem btnprint;
    private javax.swing.JButton btnsearch;
    private javax.swing.JButton btnupdate;
    private javax.swing.JComboBox<String> cbperan;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JMenuItem micontact;
    private javax.swing.JMenuItem mihome;
    private javax.swing.JTable tblpengguna;
    private javax.swing.JTextField txtcari;
    private javax.swing.JTextField txtnama_pengguna;
    private javax.swing.JTextField txtpassword;
    private javax.swing.JTextField txtusername;
    // End of variables declaration//GEN-END:variables
}
