/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package aplikasigudangseafod;

import java.awt.print.PrinterException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.MessageFormat;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class databarang extends javax.swing.JFrame {

    private DefaultTableModel model = null;
    private PreparedStatement stat;
    private ResultSet rs;
    koneksi db = new koneksi();
    private int id_pengguna = 0;
    String peran = "";
    
    public databarang() {
        initComponents();
        db.connect();
        table();
        refreshCombo();
    }

    public void setId_pengguna(int id_pengguna) {
        this.id_pengguna = id_pengguna;
    }

    public void setPeran(String peran) {
        this.peran = peran;
    }
    
    class barang extends databarang {
        int id_barang, stok_barang, id_gudang, harga_beli, harga_jual;
        String nama_barang, jenis_barang, nama_gudang;
        public barang() {
            this.nama_barang = txt_nama.getText();
            this.jenis_barang = cb_jenis.getSelectedItem().toString();
            String combo = cb_gudang.getSelectedItem().toString();
            String[] arr = combo.split(":");
            this.id_gudang = Integer.parseInt(arr[0]);
            this.nama_gudang = arr[1];
            this.stok_barang = Integer.parseInt(txtstok.getText());
            this.harga_beli = Integer.parseInt(txt_hargabeli.getText());
            this.harga_jual = Integer.parseInt(txt_hargajual.getText());
        }
    }
    
    public void table() {
        try {
            this.stat = db.getCon().prepareStatement("select * from barang");
            this.rs = stat.executeQuery();
            
            model = new DefaultTableModel();
            model.addColumn("No");
            model.addColumn("Nama");
            model.addColumn("Jenis");
            model.addColumn("Gudang");
            model.addColumn("Stok");
            model.addColumn("Harga Beli");
            model.addColumn("Harga Jual");
            
            model.getDataVector().removeAllElements();
            model.fireTableDataChanged();
            
            while (rs.next()){
                Object[] data ={
                    rs.getString("id_barang"),
                    rs.getString("nama_barang"),
                    rs.getString("jenis_barang"),
                    rs.getString("nama_gudang"),
                    rs.getString("stok_barang"),
                    rs.getString("harga_beli"),
                    rs.getString("harga_jual")
                };
                model.addRow(data);
                tbl_barang.setModel(model);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        txt_nama.setText("");
        txtstok.setText("");
        txt_hargabeli.setText("");
        txt_hargajual.setText("");
    }
    
    public void refreshCombo() {
        try {
            this.stat = db.getCon().prepareStatement("select * from gudang");
            this.rs = this.stat.executeQuery();
            while(rs.next()) {
                cb_gudang.addItem(rs.getInt("id_gudang")+":"+rs.getString("nama_gudang"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    // Method untuk menambahkan data pengguna ke dalam database
    public void input() {
        try {
            barang b = new barang();
            this.stat = db.getCon().prepareStatement("insert into barang values(?,?,?,?,?,?,?,?)");

            stat.setInt(1, 0);
            stat.setString(2, b.nama_barang);
            stat.setString(3, b.jenis_barang);
            stat.setInt(4, b.id_gudang);
            stat.setString(5, b.nama_gudang);
            stat.setInt(6, b.stok_barang);
            stat.setDouble(7, b.harga_beli);
            stat.setDouble(8, b.harga_jual);
           
            stat.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data berhasil ditambahkan!");
            table();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    // Method untuk mengedit data pengguna pada database
    public void editData() {
        try {
            barang b = new barang();
            int row = tbl_barang.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(null, "Silakan pilih data yang akan diubah!");
                return;
            }
            this.stat = db.getCon().prepareStatement ("UPDATE barang SET nama_barang=?, jenis_barang=?, id_gudang=?, nama_gudang=?, stok_barang=?, harga_beli=?, harga_jual=? WHERE id_barang=?");

            stat.setString(1, b.nama_barang);
            stat.setString(2, b.jenis_barang);
            stat.setInt(3, b.id_gudang);
            stat.setString(4, b.nama_gudang);
            stat.setInt(5, b.stok_barang);
            stat.setDouble(6, b.harga_beli);
            stat.setDouble(7, b.harga_jual);
            stat.setString(8, tbl_barang.getValueAt(row, 0).toString());

            stat.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data berhasil diubah!");
            table();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    // Method untuk menghapus data pengguna dari database
    public void hapusData() {
        int row = tbl_barang.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(null, "Silakan pilih data yang akan dihapus!");
                return;
            }else {
                int jawab = JOptionPane.showConfirmDialog(null, "Data ini akan dihapus, lanjutkan?", "konfirmasi", JOptionPane.YES_NO_OPTION);
                if (jawab == 0) {
                    try {
                        this.stat = db.getCon().prepareStatement("delete from barang where id_barang=?");

                        stat.setString(1, tbl_barang.getValueAt(row, 0).toString());

                        stat.executeUpdate();
                        JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
                        table();
                    } catch (Exception e) {
                    }
                }
            }
    }
    
    // Method untuk mencari data pengguna berdasarkan nama pengguna atau username
    public void cariData() {
        try {
            String keyword = txtcari.getText();
            this.stat = db.getCon().prepareStatement("SELECT * FROM barang WHERE nama_barang LIKE '%" + keyword + "%' OR jenis_barang LIKE '%" + keyword + "%' OR nama_gudang LIKE '%" + keyword + "%' OR stok_barang LIKE '%" + keyword + "%' OR harga_beli LIKE '%" + keyword + "%' OR harga_jual LIKE '%" + keyword + "%'");
            rs = stat.executeQuery();

            model = new DefaultTableModel();
            model.addColumn("No");
            model.addColumn("Nama");
            model.addColumn("Jenis");
            model.addColumn("Gudang");
            model.addColumn("Stok");
            model.addColumn("Harga Beli");
            model.addColumn("Harga Jual");

            model.getDataVector().removeAllElements();
            model.fireTableDataChanged();

            while (rs.next()) {
                Object[] data = {
                    rs.getString("id_barang"),
                    rs.getString("nama_barang"),
                    rs.getString("jenis_barang"),
                    rs.getString("nama_gudang"),
                    rs.getString("stok_barang"),
                    rs.getString("harga_beli"),
                    rs.getString("harga_jual")
                };
                model.addRow(data);
                tbl_barang.setModel(model);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    // Method untuk menampilkan data pengguna pada field input
    public void tampilData() {
        txt_nama.setText(tbl_barang.getValueAt(tbl_barang.getSelectedRow(), 1).toString());
        txtstok.setText(tbl_barang.getValueAt(tbl_barang.getSelectedRow(), 4).toString());
        txt_hargabeli.setText(tbl_barang.getValueAt(tbl_barang.getSelectedRow(), 5).toString());
        txt_hargajual.setText(tbl_barang.getValueAt(tbl_barang.getSelectedRow(), 6).toString());
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txt_nama = new javax.swing.JTextField();
        cb_jenis = new javax.swing.JComboBox<>();
        cb_gudang = new javax.swing.JComboBox<>();
        txtstok = new javax.swing.JTextField();
        txt_hargabeli = new javax.swing.JTextField();
        txt_hargajual = new javax.swing.JTextField();
        btn_input = new javax.swing.JButton();
        btn_update = new javax.swing.JButton();
        btn_delete = new javax.swing.JButton();
        btn_search = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_barang = new javax.swing.JTable();
        txtcari = new javax.swing.JTextField();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        btnprint = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        btnhome = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        micontact = new javax.swing.JMenuItem();

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        jLabel1.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("DATA BARANG");

        jLabel2.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel2.setText("Nama");

        jLabel3.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel3.setText("Jenis");

        jLabel4.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel4.setText("Gudang");

        jLabel5.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel5.setText("Stok");

        jLabel6.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel6.setText("Harga Beli");

        jLabel7.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel7.setText("Harga Jual");

        txt_nama.setFont(new java.awt.Font("Consolas", 0, 14)); // NOI18N
        txt_nama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_namaActionPerformed(evt);
            }
        });

        cb_jenis.setFont(new java.awt.Font("Consolas", 0, 14)); // NOI18N
        cb_jenis.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ikan Segar", "Ikan Beku", "Udang Segar", "Udang Beku", "Cumi Segar", "Cumi Beku", "Lobster Segar", "Lobster Beku", "Kerang Segar", "Kerang Beku", "Rajungan Segar", "Rajungan Beku" }));

        cb_gudang.setFont(new java.awt.Font("Consolas", 0, 14)); // NOI18N
        cb_gudang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cb_gudangActionPerformed(evt);
            }
        });

        txtstok.setFont(new java.awt.Font("Consolas", 0, 14)); // NOI18N

        txt_hargabeli.setFont(new java.awt.Font("Consolas", 0, 14)); // NOI18N

        txt_hargajual.setFont(new java.awt.Font("Consolas", 0, 14)); // NOI18N

        btn_input.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btn_input.setText("Input");
        btn_input.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_inputActionPerformed(evt);
            }
        });

        btn_update.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btn_update.setText("Update");
        btn_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_updateActionPerformed(evt);
            }
        });

        btn_delete.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btn_delete.setText("Delete");
        btn_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_deleteActionPerformed(evt);
            }
        });

        btn_search.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btn_search.setText("Search");
        btn_search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_searchActionPerformed(evt);
            }
        });

        tbl_barang.setFont(new java.awt.Font("Consolas", 0, 14)); // NOI18N
        tbl_barang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "No", "Nama", "Jenis", "Gudang", "Stok", "Harga Beli", "Harga Jual"
            }
        ));
        tbl_barang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_barangMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tbl_barang);

        txtcari.setFont(new java.awt.Font("Consolas", 0, 14)); // NOI18N
        txtcari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcariActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 662, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btn_search)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel2))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_hargabeli, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_hargajual, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtstok, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cb_gudang, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cb_jenis, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_nama, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(txtcari, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btn_input)
                                .addGap(63, 63, 63)
                                .addComponent(btn_delete)
                                .addGap(56, 56, 56)))
                        .addComponent(btn_update)))
                .addContainerGap(18, Short.MAX_VALUE))
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txt_nama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cb_jenis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cb_gudang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtstok, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txt_hargabeli, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txt_hargajual, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_update)
                    .addComponent(btn_input)
                    .addComponent(btn_delete)
                    .addComponent(btn_search)
                    .addComponent(txtcari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(32, Short.MAX_VALUE))
        );

        jMenu1.setText("File");

        btnprint.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ikon/export.png"))); // NOI18N
        btnprint.setText("Print");
        btnprint.setHideActionText(true);
        btnprint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnprintActionPerformed(evt);
            }
        });
        jMenu1.add(btnprint);
        jMenu1.add(jSeparator2);

        btnhome.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ikon/home.png"))); // NOI18N
        btnhome.setText("Home");
        btnhome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhomeActionPerformed(evt);
            }
        });
        jMenu1.add(btnhome);

        jMenuBar1.add(jMenu1);

        jMenu4.setText("Help");

        micontact.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ikon/contact.png"))); // NOI18N
        micontact.setText("Contact ");
        micontact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                micontactActionPerformed(evt);
            }
        });
        jMenu4.add(micontact);

        jMenuBar1.add(jMenu4);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txt_namaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_namaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_namaActionPerformed

    private void btn_inputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_inputActionPerformed
        input();
    }//GEN-LAST:event_btn_inputActionPerformed

    private void txtcariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcariActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcariActionPerformed

    private void btnhomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhomeActionPerformed
        home home1 = new home();
        home1.setId_pengguna(id_pengguna);
        home1.setPeran(peran);
        home1.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnhomeActionPerformed

    private void micontactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_micontactActionPerformed
        JOptionPane.showMessageDialog(null, "Dimas-085236795262");
    }//GEN-LAST:event_micontactActionPerformed

    private void btn_searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_searchActionPerformed
        cariData();
    }//GEN-LAST:event_btn_searchActionPerformed

    private void btnprintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnprintActionPerformed
        MessageFormat header = new MessageFormat("Data Barang");
        MessageFormat footer = new MessageFormat("Gudang Seafod");
        
        try {
            tbl_barang.print(JTable.PrintMode.FIT_WIDTH, header, footer);
        } catch (PrinterException e) {
            JOptionPane.showMessageDialog(null,"Cannot be print" + e.getMessage());
        }
    }//GEN-LAST:event_btnprintActionPerformed

    private void cb_gudangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cb_gudangActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cb_gudangActionPerformed

    private void tbl_barangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_barangMouseClicked
        tampilData();
    }//GEN-LAST:event_tbl_barangMouseClicked

    private void btn_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_deleteActionPerformed
        hapusData();
    }//GEN-LAST:event_btn_deleteActionPerformed

    private void btn_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_updateActionPerformed
        editData();
    }//GEN-LAST:event_btn_updateActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(databarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(databarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(databarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(databarang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new databarang().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_delete;
    private javax.swing.JButton btn_input;
    private javax.swing.JButton btn_search;
    private javax.swing.JButton btn_update;
    private javax.swing.JMenuItem btnhome;
    private javax.swing.JMenuItem btnprint;
    private javax.swing.JComboBox<String> cb_gudang;
    private javax.swing.JComboBox<String> cb_jenis;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JMenuItem micontact;
    private javax.swing.JTable tbl_barang;
    private javax.swing.JTextField txt_hargabeli;
    private javax.swing.JTextField txt_hargajual;
    private javax.swing.JTextField txt_nama;
    private javax.swing.JTextField txtcari;
    private javax.swing.JTextField txtstok;
    // End of variables declaration//GEN-END:variables
}
