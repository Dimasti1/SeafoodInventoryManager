package aplikasigudangseafod;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class koneksi {
    private String url = "jdbc:mysql://localhost/db_aplikasigudangseafod";
    private String user = "root";
    private String pass = "";
    private Connection con;
    
    public void connect() {
        try {
            con = DriverManager.getConnection(url, user, pass);
            System.out.println("Koneksi berhasil");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Koneksi gagal");
        }
    }
    
    public Connection getCon() {
        return con;
    }
    
    public void disconnect() {
        try {
            if (con != null) {
                con.close();  // Menutup koneksi
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
}

    